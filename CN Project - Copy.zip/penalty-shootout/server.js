const express = require('express');
const http = require('http');
const socketIO = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

app.use(express.static('public'));

let players = [];
let gameState = {
  shooterChoice: null,
  keeperChoice: null
};

io.on('connection', socket => {
  console.log('A user connected:', socket.id);
  players.push(socket);

  if (players.length === 2) {
    players[0].emit('role', 'shooter');
    players[1].emit('role', 'keeper');
    io.emit('message', 'Game started!');
  }

  socket.on('shot', dir => {
    gameState.shooterChoice = dir;
    checkResult();
  });

  socket.on('dive', dir => {
    gameState.keeperChoice = dir;
    checkResult();
  });

  function checkResult() {
    const { shooterChoice, keeperChoice } = gameState;
    if (shooterChoice && keeperChoice) {
      const result = shooterChoice === keeperChoice ? 'SAVE! Goalkeeper won!' : 'GOAL! Shooter win!';
      io.emit('result', { result, shooterChoice, keeperChoice });
      gameState = { shooterChoice: null, keeperChoice: null };
    }
  }

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
    players = players.filter(p => p.id !== socket.id);
    io.emit('message', 'A player disconnected.');
  });
});

server.listen(3000, () => console.log('Server running on http://localhost:3000'));
