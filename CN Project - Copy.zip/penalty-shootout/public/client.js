const socket = io();
let role = '';

const keeper = document.getElementById('keeper');
const ball = document.getElementById('ball');
const resultText = document.getElementById('result');

socket.on('role', r => {
  role = r;
  document.getElementById('role').innerText = `You are the ${role}`;
  showControls(role);
});

socket.on('message', msg => {
  resultText.innerText = msg;
});

socket.on('result', ({ result, shooterChoice, keeperChoice }) => {
  animateKeeper(keeperChoice);
  animateBall(shooterChoice);

  setTimeout(() => {
    resultText.innerText = `${result}`;
    resetPositions();
  }, 1800);
});

function showControls(role) {
  const controls = document.getElementById('controls');
  controls.innerHTML = '';

  ['left', 'center', 'right'].forEach(dir => {
    const btn = document.createElement('button');
    btn.innerText = dir.toUpperCase();
    btn.onclick = () => {
      if (role === 'shooter') {
        socket.emit('shot', dir);
        controls.innerHTML = '';
      } else {
        socket.emit('dive', dir);
        controls.innerHTML = '';
      }
    };
    controls.appendChild(btn);
  });
}

function animateKeeper(direction) {
  keeper.className = '';
  keeper.classList.add(direction);
}

function animateBall(direction) {
  ball.className = '';
  ball.classList.add(direction);
}

function resetPositions() {
  keeper.className = 'center';
  ball.className = '';
}
